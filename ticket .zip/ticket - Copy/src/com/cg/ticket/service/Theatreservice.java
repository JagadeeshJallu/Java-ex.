package com.cg.ticket.service;

import java.util.Map;

import ticket.Customer;
import ticket.theatre;

public interface Theatreservice {
	public double getprice(String show);
	public double setid(Customer ac);
	public Customer getbymno(long mobileNo);
	public Map<Long,Customer>getallAccount();
	public boolean cancelticket(Customer ac,long mobile);

}
