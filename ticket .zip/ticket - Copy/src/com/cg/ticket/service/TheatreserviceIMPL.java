package com.cg.ticket.service;
import ticket.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import ticket.Customer;

public class TheatreserviceIMPL implements Theatreservice {
	
	Map<Long,Customer>cd=new ConcurrentHashMap<>();
	Customer c=new Customer();
	

	@Override
	public double getprice(String show) {
		// TODO Auto-generated method stub
		double k=0;
		try
		{
		
		if(show.equalsIgnoreCase("movie"))
			
			return k=200;
		else if(show.equalsIgnoreCase("play"))
			return k=300;
		else if(show.equalsIgnoreCase("games"))
			return k=400;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
		
	}

	@Override
	public double setid(Customer ac) {
		// TODO Auto-generated method stub
		Map<Long,Customer> a=(Map<Long, Customer>) cd.put(ac.getMobileNo(), ac);
		double d=0;
		if(ac.getMobileNo()!=0)
		{
			theatre t=new theatre();
			 d=Math.random()*1000;
			t.setId(d);
			return d;
			
		}
		else
		return 0;
	}

	@Override
	public Map<Long, Customer> getallAccount() {
		// TODO Auto-generated method stub
		return cd;
	}

	@Override
	public boolean cancelticket(Customer ac,long mobile) {
		// TODO Auto-generated method stub
		boolean b=false;
		if(mobile==ac.getMobileNo())
		{
			cd.remove(mobile);
			b=true;
			return b;
		}
		else
		
		return b;
		
	}

	@Override
	public Customer getbymno(long mobileNo) {
		// TODO Auto-generated method stub
		Customer ac= cd.get(mobileNo);
		if(ac!=null)
		return ac;
		else
		return null;
	}

}
