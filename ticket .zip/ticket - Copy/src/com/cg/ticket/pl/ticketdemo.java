package com.cg.ticket.pl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.ticket.service.TheatreserviceIMPL;

import ticket.Customer;
import ticket.theatre;

public class ticketdemo {
	public static boolean validateMobile(String mobile)

	 {

	 String mobilepattern="[0-9]{10}";

	 boolean check=Pattern.matches(mobilepattern,mobile);

	 return check;



	 }


	public static void main(String[] args) throws IOException,ClassCastException {
		TheatreserviceIMPL ti=new TheatreserviceIMPL();

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		// TODO Auto-generated method stub
		System.out.println("enter no. of tickets u want");
		int k=Integer.parseInt(br.readLine());
		for(int i=0;i<k;i++)
		{
		System.out.println();
		
		System.out.println("welcome");
		
		System.out.println("Enter name");
		String s=br.readLine();
		long l=0;
		boolean b=false;
		do
		{System.out.println("enter mobile no.");
		String s1=br.readLine();
		 l=Long.parseLong(s1);
			if(validateMobile(s1))
			{
				b=true;
				break;
			}
			else
			{
				System.out.println("re enter mobile no of 10 digits");
		
				
			}
		}while(b!=true);
		System.out.println("availble shows are: \n 1.movie \n 2.play \n3.games");
		System.out.println("Enter one of the above(type name)");
		String s2=br.readLine();
		Customer c=new Customer(l,s,s2);
		double id=ti.setid(c);
		
		double p=ti.getprice(s2);
		c.setPrice(p);
		//theatre t=new theatre(l,p,id);
		System.out.println("price is" +ti.getprice(s2));
		System.out.println("ticket booked with id " +id);
		System.out.println(" all accounts are "+ti.getallAccount());
		}
		System.out.println("\n 1.My bookings \n 2.Display \n 3.Cancel ticket");
		

		int ch=0;
		do
		{
			ch++;
			
			switch(ch)
			{
			
			case 1: System.out.println("Enter mobile no. to know booking details");
					String s3=br.readLine();
					long l1=Long.parseLong(s3);
					Customer c1= ti.getbymno(l1);
					if(l1== c1.getMobileNo())
					{
						System.out.println("booking details " +ti.getbymno(l1));
					}
					else
						System.out.println("invalid ");
					break;
					
					
			case 2:System.out.println("Enter mobile no. to display the type of show");
					String s4=br.readLine();
					long l2=Long.parseLong(s4);
					Customer c2=(Customer) ti.getbymno(l2);
					if(l2==c2.getMobileNo())
					{
						System.out.println("Your show is " +c2.getShow());
					}
					else
					{
						System.out.println("invalid ");
					System.out.println("ticket details " +ti.toString());
					}
					break;
			case 3:		System.out.println("Enter mobile no. to cancel the ticket");
					String s5=br.readLine();
					long l3=Long.parseLong(s5);
					Customer c3= ti.getbymno(l3);
					if(l3==c3.getMobileNo())
					{
						System.out.println("Your booking is cancelled " +ti.cancelticket(c3,l3));
						System.out.println("cancelled ticket account is "+c3.toString());
						System.out.println("after cnacelling remaining are: "+ti.getallAccount());
					}
					else
						System.out.println("invalid ");
			default:System.out.println(" ==========> re run the program for next regestration ");
					break;
					
			}
			
		}while(ch!=3);
		
		
		
	}

}
