package ticket;

public class theatre {
	private long mobile;
	private double price;
	private double id;
	public theatre() {
		// TODO Auto-generated constructor stub
	}
	public theatre(long mobile, double price, double id) {
		super();
		this.mobile = mobile;
		this.price = price;
		this.id = id;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getId() {
		return id;
	}
	public void setId(double id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "theatre [mobile=" + mobile + ", price=" + price + ", id=" + id + "]";
	}
	

}
