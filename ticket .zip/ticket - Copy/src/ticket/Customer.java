package ticket;

public class Customer {
	
	private long mobileNo;
	private double price;
	private String name;
	private String show;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(long mobileNo, String name, String show) {
		super();
		this.mobileNo = mobileNo;
		this.name = name;
		this.show = show;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShow() {
		return show;
	}

	public void setShow(String show) {
		this.show = show;
	}

	@Override
	public String toString() {
		return "Customer [mobileNo=" + mobileNo + ", price=" + price + ", name=" + name + ", show=" + show + "]";
	}
	
	

}
